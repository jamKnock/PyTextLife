﻿Imports ScintillaNET
Imports System.Drawing
Imports System.Windows.Forms
Imports ScintillaNET.Lexilla
Imports System.IO

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.Show()

        ' Import necessary libraries

        ' Reset the styles
        Scintilla1.StyleResetDefault()
        Scintilla1.Styles(Style.Default).Font = "Consolas"
        Scintilla1.Styles(Style.Default).Size = 10
        Scintilla1.StyleClearAll() ' i.e. Apply to all

        ' Set the lexer
        Scintilla1.LexerName = "python"


        ' Some properties we like
        Scintilla1.SetProperty("tab.timmy.whinge.level", "1")
        Scintilla1.SetProperty("fold", "1")

        ' Use margin 2 for fold markers
        Scintilla1.Margins(2).Type = MarginType.Symbol
        Scintilla1.Margins(2).Mask = Marker.MaskFolders
        Scintilla1.Margins(2).Sensitive = True
        Scintilla1.Margins(2).Width = 20

        ' Reset folder markers
        For i As Integer = Marker.FolderEnd To Marker.FolderOpen
            Scintilla1.Markers(i).SetForeColor(SystemColors.ControlLightLight)
            Scintilla1.Markers(i).SetBackColor(SystemColors.ControlDark)
        Next

        ' Style the folder markers
        Scintilla1.Markers(Marker.Folder).Symbol = MarkerSymbol.BoxPlus
        Scintilla1.Markers(Marker.Folder).SetBackColor(SystemColors.ControlText)
        Scintilla1.Markers(Marker.FolderOpen).Symbol = MarkerSymbol.BoxMinus
        Scintilla1.Markers(Marker.FolderEnd).Symbol = MarkerSymbol.BoxPlusConnected
        Scintilla1.Markers(Marker.FolderEnd).SetBackColor(SystemColors.ControlText)
        Scintilla1.Markers(Marker.FolderMidTail).Symbol = MarkerSymbol.TCorner
        Scintilla1.Markers(Marker.FolderOpenMid).Symbol = MarkerSymbol.BoxMinusConnected
        Scintilla1.Markers(Marker.FolderSub).Symbol = MarkerSymbol.VLine
        Scintilla1.Markers(Marker.FolderTail).Symbol = MarkerSymbol.LCorner

        ' Enable automatic folding
        Scintilla1.AutomaticFold = (AutomaticFold.Show Or AutomaticFold.Click Or AutomaticFold.Change)

        ' Set the styles
        Scintilla1.Styles(Style.Python.Default).ForeColor = Color.FromArgb(&H80, &H80, &H80)
        Scintilla1.Styles(Style.Python.CommentLine).ForeColor = Color.FromArgb(&H0, &H7F, &H0)
        Scintilla1.Styles(Style.Python.CommentLine).Italic = True
        Scintilla1.Styles(Style.Python.Number).ForeColor = Color.FromArgb(&H0, &H7F, &H7F)
        Scintilla1.Styles(Style.Python.String).ForeColor = Color.FromArgb(&H7F, &H0, &H7F)
        Scintilla1.Styles(Style.Python.Character).ForeColor = Color.FromArgb(&H7F, &H0, &H7F)
        Scintilla1.Styles(Style.Python.Word).ForeColor = Color.FromArgb(&H0, &H0, &H7F)
        Scintilla1.Styles(Style.Python.Word).Bold = True
        Scintilla1.Styles(Style.Python.Triple).ForeColor = Color.FromArgb(&H7F, &H0, &H0)
        Scintilla1.Styles(Style.Python.TripleDouble).ForeColor = Color.FromArgb(&H7F, &H0, &H0)
        Scintilla1.Styles(Style.Python.ClassName).ForeColor = Color.FromArgb(&H0, &H0, &HFF)
        Scintilla1.Styles(Style.Python.ClassName).Bold = True
        Scintilla1.Styles(Style.Python.DefName).ForeColor = Color.FromArgb(&H0, &H7F, &H7F)
        Scintilla1.Styles(Style.Python.DefName).Bold = True
        Scintilla1.Styles(Style.Python.Operator).Bold = True
        ' Scintilla1.Styles(Style.Python.Identifier) ... your keywords styled here
        Scintilla1.Styles(Style.Python.CommentBlock).ForeColor = Color.FromArgb(&H7F, &H7F, &H7F)
        Scintilla1.Styles(Style.Python.CommentBlock).Italic = True
        Scintilla1.Styles(Style.Python.StringEol).ForeColor = Color.FromArgb(&H0, &H0, &H0)
        Scintilla1.Styles(Style.Python.StringEol).BackColor = Color.FromArgb(&HE0, &HC0, &HE0)
        Scintilla1.Styles(Style.Python.StringEol).FillLine = True
        Scintilla1.Styles(Style.Python.Word2).ForeColor = Color.FromArgb(&H40, &H70, &H90)
        Scintilla1.Styles(Style.Python.Decorator).ForeColor = Color.FromArgb(&H80, &H50, &H0)

        ' Important for Python
        Scintilla1.ViewWhitespace = WhitespaceMode.VisibleAlways

        ' Keyword lists:
        ' 0 "Keywords",
        ' 1 "Highlighted identifiers"

        Dim python2 As String = "and as assert break class continue def del elif else except exec finally for from global if import in is lambda"

        Dim python3 As String = "False None True and as assert break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield"
        Dim cython As String = "cdef cimport cpdef"

        Scintilla1.SetKeywords(0, python3 & " " & cython)
        ' Scintilla1.SetKeywords(1, "add your own keywords here")




    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub FileNameText_TextChanged(sender As Object, e As EventArgs) Handles FileNameText.TextChanged
        autoSaveTimer.Enabled = False
        CheckBox1.Checked = False
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            autoSaveTimer.Interval = 1000 * Integer.Parse(inputTimeTimer.Text)
            autoSaveTimer.Enabled = True
        Else
            autoSaveTimer.Enabled = False
        End If
    End Sub

    Private Sub autoSaveTimer_Tick(sender As Object, e As EventArgs) Handles autoSaveTimer.Tick

        If CheckBox1.Checked = True And Trim(FileNameText.Text) <> "" And Trim(TextBox1.Text) <> "" And Integer.Parse(inputTimeTimer.Text) > 0 Then

            Try

                System.IO.File.WriteAllText(TextBox1.Text + "\" + FileNameText.Text, Scintilla1.Text)


            Catch ex As Exception

                MsgBox("Could not write")
                CheckBox1.Checked = False
                autoSaveTimer.Enabled = False
            End Try

        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim d As DialogResult = folderDialog.ShowDialog()

        If d = DialogResult.OK Then

            TextBox1.Text = folderDialog.SelectedPath

        End If


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim d As DialogResult = openFileDialog.ShowDialog()

        If d = DialogResult.OK Then

            Dim s As IO.Stream = openFileDialog.OpenFile()
            Dim reader As StreamReader = New StreamReader(s, System.Text.Encoding.UTF8)

            Scintilla1.Text = reader.ReadToEnd()

        End If

    End Sub
End Class
