﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Scintilla1 = New ScintillaNET.Scintilla()
        folderDialog = New FolderBrowserDialog()
        FileNameText = New TextBox()
        inputTimeTimer = New TextBox()
        CheckBox1 = New CheckBox()
        Button1 = New Button()
        autoSaveTimer = New Timer(components)
        Button2 = New Button()
        TextBox1 = New TextBox()
        openFileDialog = New OpenFileDialog()
        Button3 = New Button()
        SuspendLayout()
        ' 
        ' Scintilla1
        ' 
        Scintilla1.AutocompleteListSelectedBackColor = Color.FromArgb(CByte(0), CByte(120), CByte(215))
        Scintilla1.LexerName = Nothing
        Scintilla1.Location = New Point(12, 10)
        Scintilla1.Name = "Scintilla1"
        Scintilla1.ScrollWidth = 51
        Scintilla1.Size = New Size(683, 397)
        Scintilla1.TabIndex = 0
        ' 
        ' FileNameText
        ' 
        FileNameText.Location = New Point(12, 415)
        FileNameText.Multiline = True
        FileNameText.Name = "FileNameText"
        FileNameText.PlaceholderText = "Set Filename"
        FileNameText.ScrollBars = ScrollBars.Horizontal
        FileNameText.Size = New Size(207, 23)
        FileNameText.TabIndex = 1
        FileNameText.TextAlign = HorizontalAlignment.Center
        ' 
        ' inputTimeTimer
        ' 
        inputTimeTimer.Location = New Point(464, 413)
        inputTimeTimer.Name = "inputTimeTimer"
        inputTimeTimer.PlaceholderText = "secs"
        inputTimeTimer.Size = New Size(93, 23)
        inputTimeTimer.TabIndex = 3
        inputTimeTimer.Text = "5"
        inputTimeTimer.TextAlign = HorizontalAlignment.Center
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Location = New Point(346, 417)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(112, 19)
        CheckBox1.TabIndex = 4
        CheckBox1.Text = "AutoSave(secs.):"
        CheckBox1.TextAlign = ContentAlignment.MiddleCenter
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(563, 413)
        Button1.Name = "Button1"
        Button1.Size = New Size(132, 23)
        Button1.TabIndex = 5
        Button1.Text = "Exit"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' autoSaveTimer
        ' 
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(225, 415)
        Button2.Name = "Button2"
        Button2.Size = New Size(115, 23)
        Button2.TabIndex = 6
        Button2.Text = "Set Folder"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(12, 444)
        TextBox1.Name = "TextBox1"
        TextBox1.PlaceholderText = "Folder path"
        TextBox1.ReadOnly = True
        TextBox1.Size = New Size(328, 23)
        TextBox1.TabIndex = 7
        TextBox1.TextAlign = HorizontalAlignment.Center
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(346, 444)
        Button3.Name = "Button3"
        Button3.Size = New Size(349, 23)
        Button3.TabIndex = 8
        Button3.Text = "Open File"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        ClientSize = New Size(707, 483)
        ControlBox = False
        Controls.Add(Button3)
        Controls.Add(TextBox1)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(CheckBox1)
        Controls.Add(inputTimeTimer)
        Controls.Add(FileNameText)
        Controls.Add(Scintilla1)
        FormBorderStyle = FormBorderStyle.FixedSingle
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form1"
        SizeGripStyle = SizeGripStyle.Show
        StartPosition = FormStartPosition.CenterScreen
        Text = "PyTextLife"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Scintilla1 As ScintillaNET.Scintilla
    Friend WithEvents folderDialog As FolderBrowserDialog
    Friend WithEvents FileNameText As TextBox
    Friend WithEvents inputTimeTimer As TextBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Button1 As Button
    Friend WithEvents autoSaveTimer As Timer
    Friend WithEvents Button2 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents openFileDialog As OpenFileDialog
    Friend WithEvents Button3 As Button

End Class
